// Load Styles.
import './styles/application.scss';

// Load Scripts.
import './scripts/index';
